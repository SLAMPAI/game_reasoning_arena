TODO: describe how we obtained the actions, rewards, etc.
