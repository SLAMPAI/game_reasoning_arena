Shared utility functions (e.g., prompt generation, LLM integration).
