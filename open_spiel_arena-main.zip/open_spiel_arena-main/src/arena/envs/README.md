Simulation logic for each game.
