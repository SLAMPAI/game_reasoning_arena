Games-specific playing logic
