#!/usr/bin/env python3
"""
train.py

Place-holder script for RL training.
It might set up a training loop, or rely on an RL library.
"""


def main():
    pass


    # 1. Load game, build environment
    # 2. Create your RL agent/policy
    # 3. for episode in range(args.episodes):
    #       reset environment
    #       while not done:
    #           step with agent
    #           collect transitions
    #       update agent



if __name__ == "__main__":
    main()
